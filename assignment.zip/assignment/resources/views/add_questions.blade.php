<!DOCTYPE html>
<html>
  <head>

    <title></title>
    <link href="{{ URL::asset('css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('css/bootstrap-responsive.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('css/bootstrap-responsive.min.css') }}" rel="stylesheet">

    <div class="navbar">
  <div class="navbar-inner">
    <div class="container">
     <ul class="nav">
        <li class="active"><a href="{{ route('questionairs.index') }}">Home</a></li>
        <li><a href="{{ route('questionairs.create') }}">Questionairs</a></li>
        <li><a href="#">Result</a></li>  
      </ul>

      <ul class="nav pull-right">
          <li><a href="#">Profile</a></li>
          <li><a href="#">Logout</a></li>
        </ul>

    </div>
  </div>
</div>

  </head>
  <body>
   

  <div class="container">
    <form class="form-horizontal well" method="POST" action="{{ route('questionairs.store') }}">
      {{ csrf_field() }}
      <fieldset>
        <legend>Create</legend>
        <div class="control-group">

          <label class="control-label">Questionair Name</label>
          <div class="controls">
            <input type="text" class="input-large" name="qname" placeholder="Enter Questionair Name">
          </div>

          <br>

          <label class="control-label">Duration</label>
          <div class="controls">
            <input type="number" class="input-small" name="duration"  placeholder="Enter Duration">
            <select class="input-small" name="time">
              <option value="Minutes">Minutes</option>
              <option value="Hours">Hours</option>
            </select>
          </div>  
        

          <br>

          <label class="control-label">Can Resume?</label>
          <div class="controls">
            <input type="radio" name="resume" value="Yes"> Yes
            <input type="radio" name="resume" value="No"> No
          </div>

          <br>

          <div class="controls">  
            <button type="submit" class="btn">Save</button>
          </div>  

        </div>
      </fieldset>
    </form>
  </div>


  </body>
  <script src="{{ URL::asset('js/bootstrap.js') }}"></script>
  <script src="{{ URL::asset('js/bootstrap.min.js') }}"></script>
</html>

