<!DOCTYPE html>
<html>
  <head>

    <title></title>
    <link href="{{ URL::asset('css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('css/bootstrap-responsive.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('css/bootstrap-responsive.min.css') }}" rel="stylesheet">

    <div class="navbar">
  <div class="navbar-inner">
    <div class="container">
     <ul class="nav">
        <li class="active"><a href="{{ route('questionairs.index') }}">Home</a></li>
        <li><a href="{{ route('questionairs.create') }}">Questionairs</a></li>
        <li><a href="#">Result</a></li>  
      </ul>

      <ul class="nav pull-right">
          <li><a href="#">Profile</a></li>
          <li><a href="#">Logout</a></li>
        </ul>

    </div>
  </div>
</div>
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    $(document).on("click", ".close-div", function(e) {
  e.preventdefault;
  $(this).closest('.controls').parents('.question').fadeOut(300);

});

     $(document).on("click", ".delete-question", function(e) {
  e.preventdefault;
  $(this).closest('.delete-question').parents('.close-question').fadeOut(300);

});


   $(document).on("click", ".add-question", function(e) {
    e.preventdefault;
  $(".addd-question").append(' <div class="question"><label class="control-label">Choice</label><div class="controls"><input type="text" class="input-large" name="" placeholder="Enter Choice"><input type="checkbox" name="">  Correct ?<a href="#" class="close-div">Delete Choice</a></div></div>');
});

  </script>

  </head>
  <body>
   

  <div class="container">
    <form class="form-horizontal well" method="POST" action="#">
      {{ csrf_field() }}
      <fieldset>
        <legend>Add Questions</legend>
        <div class="control-group">

          <label class="control-label">Question Type</label>
          <div class="controls">
            <select class="input-small" name="qtype">
              <option value="Text">Text</option>
              <option value="MCQs">MCQs</option>
            </select>
          </div> 

          <br>

          <label class="control-label">Question</label>
          <div class="controls">
            <input type="text" class="input-large" name="qname" placeholder="Enter Questionair">
            <a href="#">Delete Questions</a>
          </div>

          <br>

          <label class="control-label">Answer</label>
          <div class="controls">
            <input type="text" class="input-large" name="aname" placeholder="Enter Answer">
          </div>

          <hr>

          <div class="close-question">
            <label class="control-label">Question Type</label>
            <div class="controls">
              <select class="input-large" name="">
                <option value="Single">Multiple Choice (Single Option)</option>
                <option value="Single">Multiple Choice (Multiple Option)</option>
              </select>
              <a href="#" class="delete-question">Delete Question</a>
            </div> 

            <br>

            <label class="control-label">Question</label>
            <div class="controls">
              <input type="text" class="input-large" name="" placeholder="Enter Questionair">
            </div>

            <br>

            <div class="question">
              <label class="control-label">Choice</label>
              <div class="controls">
                <input type="text" class="input-large" name="" placeholder="Enter Choice">
                <input type="checkbox" name=""> Correct ?
                <a href="#" class="close-div">Delete Choice</a>
              </div>
            </div>

            <div class="question">
              <label class="control-label">Choice</label>
              <div class="controls">
                <input type="text" class="input-large" name="" placeholder="Enter Choice">
                <input type="checkbox" name=""> Correct ?
                <a href="#" class="close-div">Delete Choice</a>
              </div>
            </div>

            <div class="question">
              <label class="control-label">Choice</label>
               <div class="controls">
                <input type="text" class="input-large" name="" placeholder="Enter Choice">
                <input type="checkbox" name=""> Correct ?
                <a href="#" class="close-div">Delete Choice</a>
              </div>
            </div>

            <div class="addd-question"></div>

            <div class="controls">
              <a href="#" class="add-question">Add Choice</a>
            </div>        

          </div>
          <hr>

          <div class="close-question">
            <label class="control-label">Question Type</label>
            <div class="controls">
              <select class="input-large" name="">
                <option value="Single">Multiple Choice (Single Option)</option>
                <option value="Single">Multiple Choice (Multiple Option)</option>
              </select>
              <a href="#" class="delete-question">Delete Question</a>
            </div> 

            <br>

            <label class="control-label">Question</label>
            <div class="controls">
              <input type="text" class="input-large" name="" placeholder="Enter Questionair">
            </div>

            <br>

            <div class="question">
              <label class="control-label">Choice</label>
              <div class="controls">
                <input type="text" class="input-large" name="" placeholder="Enter Choice">
                <input type="checkbox" name=""> Correct ?
                <a href="#" class="close-div">Delete Choice</a>
              </div>
            </div>
            
            <div class="question">
              <label class="control-label">Choice</label>
              <div class="controls">
                <input type="text" class="input-large" name="" placeholder="Enter Choice">
                <input type="checkbox" name=""> Correct ?
                <a href="#" class="close-div">Delete Choice</a>
              </div>
            </div>

            <div class="question">
              <label class="control-label">Choice</label>
               <div class="controls">
                <input type="text" class="input-large" name="" placeholder="Enter Choice">
                <input type="checkbox" name=""> Correct ?
                <a href="#" class="close-div">Delete Choice</a>
              </div>
            </div>

            <div class="addd-question"></div>

            <div class="controls">
              <a href="#" class="add-question">Add Choice</a>
            </div>        

          </div>
                    
          <hr>
          
          <div class="controls">  
            <button type="submit" class="btn">Save</button>
          </div>  

        </div>
      </fieldset>
    </form>
  </div>


  </body>
  <script src="{{ URL::asset('js/bootstrap.js') }}"></script>
  <script src="{{ URL::asset('js/bootstrap.min.js') }}"></script>
</html>

