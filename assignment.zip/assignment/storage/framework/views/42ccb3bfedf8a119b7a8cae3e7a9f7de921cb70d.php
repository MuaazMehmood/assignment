<!DOCTYPE html>
<html>
  <head>

    <title></title>
    <link href="<?php echo e(URL::asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('css/bootstrap-responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('css/bootstrap-responsive.min.css')); ?>" rel="stylesheet">

    <div class="navbar">
  <div class="navbar-inner">
    <div class="container">
     <ul class="nav">
        <li class="active"><a href="<?php echo e(route('questionairs.index')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('questionairs.create')); ?>">Questionairs</a></li>
        <li><a href="#">Result</a></li>  
      </ul>

      <ul class="nav pull-right">
          <li><a href="#">Profile</a></li>
          <li><a href="#">Logout</a></li>
        </ul>

    </div>
  </div>
</div>

  </head>
  <body>
    <div class="container">
     <h2>Questionair</h2>
    </div>
    
    <div class="row">
      <div class="container">
  
        <div class="col-md-8">
          <table class="table table-striped table table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Number of Questions</th>
                <th>Duration</th>
                <th>Resumeable</th>
                <th>Published</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                 $i = 1
              ?>
              <?php $__currentLoopData = $que; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($ques->qname); ?></td>
                <td>
                  <a href="<?php echo e(route('add.index')); ?>">ADD</a>
                </td>
                <td><?php echo e($ques->duration); ?> <?php echo e($ques->time); ?></td>                
                <td><?php echo e($ques->resume); ?></td>
                
                <td>…</td>
                <td>
                  Edit |
                  <span  style="display: inline-block;">
                    <form action="<?php echo e(route('questionairs.destroy', $ques->id)); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>              
                      <button title="Delete" type="submit" name="" class="btn btn-danger btn-simple btn-xs">
                      </button>                                                    
                    </form> 
                  </span>  
                </td>  
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
    </div>

  </body>
  <script src="<?php echo e(URL::asset('js/bootstrap.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
</html>

